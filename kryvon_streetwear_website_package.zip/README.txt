KRYVON STREETWEAR — Website files

QUICK START (GitHub Pages)
1. Sign in to your own GitHub account.
2. Create a NEW PUBLIC repository named kryvon-store.
3. Upload index.html (this file) to the top/root of the repository.
4. Open repository Settings → Pages.
5. Under Build and deployment, select Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for publishing; return to Settings → Pages and tap Visit site.

Important:
- Keep the GitHub account and recovery details under your control.
- A public GitHub Pages site and its repository contents can be seen by anyone.
- The WhatsApp number in the website will be visible to visitors.
- Product names, sample prices, and illustrations are demo content; confirm real prices, sizes, delivery terms, and product photos before accepting orders.
- This is a static website. Orders are sent to WhatsApp; there is no private admin dashboard or online payment system yet.
